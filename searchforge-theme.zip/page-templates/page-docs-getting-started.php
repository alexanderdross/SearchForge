<?php
/**
 * Template Name: Docs - Getting Started
 *
 * @package SearchForge_Theme
 */

get_header();

$sections = [
	[ 'id' => 'installation',                    'label' => 'Installation',                    'title' => 'How to install SearchForge on WordPress' ],
	[ 'id' => 'license-activation',              'label' => 'License Activation',              'title' => 'Activate your SearchForge license key' ],
	[ 'id' => 'connecting-google-search-console', 'label' => 'Connecting Google Search Console', 'title' => 'Connect Google Search Console to SearchForge' ],
	[ 'id' => 'connecting-additional-sources',    'label' => 'Additional Data Sources',         'title' => 'Connect additional SEO data sources to SearchForge' ],
	[ 'id' => 'your-first-data-sync',            'label' => 'Your First Data Sync',            'title' => 'Run your first SEO data sync with SearchForge' ],
	[ 'id' => 'exporting-your-first-brief',      'label' => 'Exporting Your First Brief',      'title' => 'Export your first AI-ready SEO brief' ],
];
?>

<section class="sf-section sf-section--dark sf-hero" style="padding: var(--space-3xl) 0;">
	<div class="sf-container" style="text-align: center;">
		<h1><span class="sf-gradient-text">Getting Started</span></h1>
		<p class="sf-text--inverse-muted" style="font-size: 1.25rem; max-width: 640px; margin: var(--space-md) auto 0;">
			Install SearchForge, activate your license, connect Google Search Console, and export your first SEO brief in under 10 minutes.
		</p>
	</div>
</section>

<section class="sf-section">
	<div class="sf-container">
		<div class="sf-doc-layout">
			<?php sf_doc_sidebar( $sections ); ?>
			<div class="sf-doc-content">

		<article class="sf-doc-section" id="installation">
			<h2>Installation</h2>
			<p>SearchForge installs like any WordPress plugin. Download the ZIP from your account dashboard or install directly from the WordPress plugin directory.</p>
			<ol class="sf-content">
				<li>Go to <strong>Plugins &rarr; Add New</strong> in your WordPress admin.</li>
				<li>Click <strong>Upload Plugin</strong> and select the <code>searchforge.zip</code> file.</li>
				<li>Click <strong>Install Now</strong>, then <strong>Activate</strong>.</li>
				<li>The SearchForge menu appears in your admin sidebar.</li>
			</ol>
			<p>Requirements: WordPress 6.0+, PHP 8.2+, and a valid SSL certificate for OAuth connections.</p>
		</article>

		<hr style="border: none; border-top: 1px solid var(--sf-border); margin: var(--space-2xl) 0;">

		<article class="sf-doc-section" id="license-activation">
			<h2>License Activation</h2>
			<p>Free tier works without a license key. For Pro, Agency, or Enterprise, enter your key in <strong>SearchForge &rarr; Settings &rarr; License</strong>.</p>
			<ol class="sf-content">
				<li>Copy your license key from the purchase confirmation email or your account at <code>searchforge.drossmedia.de/account/</code>.</li>
				<li>Navigate to <strong>SearchForge &rarr; Settings &rarr; License</strong>.</li>
				<li>Paste the key and click <strong>Activate</strong>.</li>
				<li>Your tier and expiry date appear immediately. Features unlock within seconds.</li>
			</ol>
			<p>Each license is valid for one production domain. Development domains (<code>localhost</code>, <code>*.local</code>, <code>*.dev</code>, <code>*.test</code>) are free and unlimited.</p>
		</article>

		<hr style="border: none; border-top: 1px solid var(--sf-border); margin: var(--space-2xl) 0;">

		<article class="sf-doc-section" id="connecting-google-search-console">
			<h2>Connecting Google Search Console</h2>
			<p>Google Search Console is the primary data source and works on every tier, including Free.</p>
			<ol class="sf-content">
				<li>Go to <strong>SearchForge &rarr; Data Sources</strong>.</li>
				<li>Click <strong>Connect Google Search Console</strong>.</li>
				<li>Sign in with the Google account that has access to your GSC property.</li>
				<li>Grant the requested permissions (read-only access to Search Console data).</li>
				<li>Select your GSC property from the dropdown and click <strong>Save</strong>.</li>
			</ol>
			<p>SearchForge uses OAuth 2.0  - your credentials are never stored. The access token is stored securely in your WordPress database.</p>
		</article>

		<hr style="border: none; border-top: 1px solid var(--sf-border); margin: var(--space-2xl) 0;">

		<article class="sf-doc-section" id="connecting-additional-sources">
			<h2>Connecting Additional Data Sources</h2>
			<p>Pro and above tiers can connect up to 9 data sources. After GSC, consider connecting these for richer briefs:</p>
			<ul class="sf-content">
				<li><strong>Bing Webmaster Tools</strong> - Bing-specific search data via API key or OAuth.</li>
				<li><strong>Google Analytics 4</strong> - On-page behavior metrics (bounce rate, engagement, conversions). Uses the same Google OAuth as GSC.</li>
				<li><strong>Google Keyword Planner</strong> - Search volume and competition data. Requires a Google Ads account.</li>
				<li><strong>Google Trends</strong> - Relative interest and rising queries. Requires a SerpApi key.</li>
				<li><strong>Google Business Profile</strong> - Local SEO data for physical locations.</li>
				<li><strong>Bing Places</strong> - Bing local search data.</li>
				<li><strong>Adobe Analytics</strong> - Enterprise behavior metrics via the Adobe Analytics 2.0 API. Requires Adobe Developer Console credentials (Organization ID, Client ID, Client Secret) and a Report Suite ID.</li>
			</ul>
			<p>Configure all sources at <strong>SearchForge - Data Sources</strong>. Each source enriches your briefs with additional context.</p>
		</article>

		<hr style="border: none; border-top: 1px solid var(--sf-border); margin: var(--space-2xl) 0;">

		<article class="sf-doc-section" id="your-first-data-sync">
			<h2>Your First Data Sync</h2>
			<p>After connecting GSC, trigger your first sync to pull ranking data into SearchForge.</p>
			<ol class="sf-content">
				<li>Go to <strong>SearchForge &rarr; Dashboard</strong>.</li>
				<li>Click <strong>Sync Now</strong> or wait for the automatic daily sync.</li>
				<li>SearchForge pulls clicks, impressions, CTR, and position data for each page and keyword.</li>
				<li>Free tier: up to 10 pages and 100 keywords. Pro: unlimited.</li>
			</ol>
			<p>The first sync usually takes 30-60 seconds depending on your site size. Subsequent syncs are incremental and faster.</p>
		</article>

		<hr style="border: none; border-top: 1px solid var(--sf-border); margin: var(--space-2xl) 0;">

		<article class="sf-doc-section" id="exporting-your-first-brief">
			<h2>Exporting Your First Brief</h2>
			<p>The core output of SearchForge is the per-page markdown brief  - a structured document ready for LLMs.</p>
			<ol class="sf-content">
				<li>Navigate to <strong>SearchForge &rarr; Pages</strong> and click any page.</li>
				<li>Review the data summary: rankings, top keywords, trends, and SearchForge Score.</li>
				<li>Click <strong>Export Markdown Brief</strong>.</li>
				<li>Copy the brief and paste it into Claude Code, ChatGPT, or save it as a <code>.md</code> file.</li>
			</ol>
			<p>The brief includes all the context an LLM needs to give you actionable SEO recommendations for that specific page.</p>
		</article>

			</div>
		</div>
	</div>
</section>

<section class="sf-section sf-section--light" style="text-align: center;">
	<div class="sf-container sf-container--narrow">
		<p class="sf-text--muted">
			<a href="<?php echo esc_url( home_url( '/docs/' ) ); ?>" title="SearchForge Documentation - Setup, Configuration &amp; API Reference">&larr; Back to Documentation</a>
		</p>
	</div>
</section>

<?php
get_footer();
